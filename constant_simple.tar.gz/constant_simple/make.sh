#! /bin/csh

source ~/.xsi_3.0
make $*
