#! /bin/sh

. XSI_Setenv.sh

echo "Loading XSI..."
$XSI_BINDIR $* 
