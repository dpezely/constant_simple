#! /bin/sh

. XSI_Setenv.sh
make $*
